---
layout: post_page
title: DeLorean
---

My insurance, it's your car, your insurance should pay for it. Hey, I wanna know who's gonna pay for this? I spilled beer all over it when that car smashed into me. Who's gonna pay my cleaning bill? Leave me alone. Shape up, man. You're a slacker. You wanna be a slacker for the rest of your life? Doc, you gotta help me. you were the only one who knows how your time machine works. Y'know this time it wasn't my fault. The Doc set all of his clocks twenty-five minutes slow.

Yeah, it's in the back. Precisely. About 30 years, it's a nice round number. So what's it to you, butthead. You know you've been looking for a, since you're new here, I'm gonna cut you a break, today. So why don't you make like a tree, and get out of here. Ronald Reagon.

Where the hell are they. Right. I don't like her, Marty. Any girl who calls a boy is just asking for trouble. Hey beat it, spook, this don't concern you. No no no this sucker's electrical, but I need a nuclear reaction to generate the one point twenty-one gigawatts of electricity-