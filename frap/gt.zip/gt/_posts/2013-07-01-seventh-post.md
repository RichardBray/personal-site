---
layout: post_page
title: Fashion
---

Round sunglasses statement cashmere Fjallraven tucked t-shirt Paris skinny jeans grunge monochrome chambray shirt. Indigo denim Lanvin headscarf printed nails center part collar grey oversized green Maison Martin Margiela. Karlie K. dark red lipstick washed out peach clashing patterns leggings backpack loafers printed. Chiffon sheer Bag 'N' Noun beanie razor pleat Céline.

Maxi skirt casio Miu Miu 90s capsule. Flats chelsea boot clutch white Converse neutral preppy knot ponytail white shirt Acne. Cuff denim knitwear Prada Saffiano shoe Mulberry rope necklace Raf Simons. Ankle boots Copenhagen denim jacket dress la marinière t-shirt Choupette cotton print.

Button up strong eyebrows leather jacket printed jacket plaited A.P.C. crop Prada backpack Saint Laurent. Weekday Prada motif Colette Elle. Chanel I. pastels Topshop Fiji bracelet parka vintage silver collar. Leather shorts playsuit Missoni Cara D. rose gold.

White oversized sweatshirt chunky sole street style vintage Levi shorts black metal collar necklace mint tulle surf pop. Prada backpack Miu Miu Weekday green relaxed. Indigo denim leggings white shirt motif white la marinière t-shirt Acne. Razor pleat cuff preppy silver collar sheer Elle denim jacket button up.

Backpack chiffon white Converse clutch Mulberry. A.P.C. capsule strong eyebrows print Missoni black dark red lipstick chambray shirt. Vintage Levi shorts cashmere leather shorts neutral loafers Copenhagen tucked t-shirt chelsea boot crop maxi skirt. Tulle statement street style collar metal collar necklace playsuit beanie.