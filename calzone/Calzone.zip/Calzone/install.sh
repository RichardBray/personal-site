#!/bin/bash

bold=`tput bold`
normal=`tput sgr0`

echo "\n1. Installing Node dependencies. This might take a while\n"; 

npm install express hbs;

npm install --save-dev nodemon gulp gulp-util gulp-sass gulp-minify-css gulp-notify gulp-autoprefixer gulp-concat gulp-uglify;

sudo npm install -g gulp; 

echo "Done"

exit 0
