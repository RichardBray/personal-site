#!/bin/bash


echo "1. Installing Node dependencies. This might take a while"; 

npm install express hbs;

npm install --save-dev nodemon gulp gulp-util gulp-sass gulp-minify-css gulp-autoprefixer gulp-concat gulp-uglify;

npm install -g gulp; #sudo

echo "Done"

exit 0
