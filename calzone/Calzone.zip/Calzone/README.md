
[Site Coming Soon](http://richbray.me/calzone/)

#Calzone

[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/RichardBray/calzone/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

A framework for font-end devs who want to get into node. Uses [express.js](http://expressjs.com/), [handlebars](http://handlebarsjs.com/), [gulp](http://gulpjs.com/) & a sass version of [bootstrap](http://getbootstrap.com/).

**That's right no jade, because most front end devs don't use html pre-processors.**


#Getting Started

Gulp runs on [nodejs](http://nodejs.org/) so if you haven't done so already – go download and install node it's a simple executable file for Mac & Windows users. I'm not sure how it works on Linux machines.

##Automatic install

1.Open the project file in your mac or linux terminal and type.

	sh install.sh

2.If you're on a windows machine type

	sh install-win.sh

3. Delete both install.sh files

4. If you're on Mac/Linux gulpfile.js if your on a Windows delete `gulpfile.js` and rename `gulpfile-win.js` to `gulpfile.js`. 	

	
**Please delete the install.sh file once you are done.**

##Manual install


1.First install all the node delendencies, there are quite a few so it might take a while.

	npm install express hbs

then

	npm install --save-dev nodemon gulp gulp-util gulp-sass gulp-minify-css gulp-notify gulp-autoprefixer gulp-concat gulp-uglify

**Windows users don't install `gulp-notify`.**


2.Install grunt globally. 

*For Windows users ignore 'sudo' but launch the command line as an Administrator instead.*

	sudo npm install -g gulp


3. Delete both install.sh files

##Running your app

You'll need to have 2 terminal windows open (3 if you want to run mongodb).

1.The first one is to run the server which you can do by typing.

	npm start

2.The second one is to run gulp by typing.

	gulp


##Documentation

I started writing some documentation – then it started to make this file really long, so I moved them all to the repos [wiki](https://github.com/RichardBray/Calzone/wiki/_pages).



##License

Calzone is licensed under the [☺ license.](http://licence.visualidiot.com/)

You, the licensee, are hereby granted free usage in both personal and commerical environments, without any obligation of attribution or payment (monetary or otherwise). The licensee is free to use, copy, modify, publish, distribute, sublicence, and/or merchandise the work, subject to the licensee inflecting a positive message unto someone. This includes (but is not limited to): smiling, being nice, saying “thank you”, assisting other persons, or any similar actions percolating the given concept.


The above copyright notice serves as a permissions notice also, and may optionally be included in copies or portions of the work.
