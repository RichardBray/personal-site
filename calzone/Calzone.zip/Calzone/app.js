var express = require('express'),
	hbs = require('hbs');
	//mongoose = require('mongoose');

var app = express();

app.configure(function (){
	app.set('view engine', 'html'); 
	app.engine('html', hbs.__express);

	/*app.use(express.json()); 
	app.use(express.url.encoded()); 
	app.use(express.methodOverride());
	app.use(app.router); */

	app.use(express.static(__dirname + "/public"));
});


//mongoose.connect("mongodb://localhost/test");

// --------  TEST DB CONNECTION  ---------
// var db = mongoose.connection;
//
// db.on('error', console.error.bind(console, 'connection error:'));
// db.once('open', function callback () {
//   console.log("\nDB is on");
// });



app.get('/', function (req, res){
	res.render('pages/index', {title:"Homepage"});
});


app.listen(4000); //changed this to whatever you want