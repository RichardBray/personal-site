#!/bin/sh

sass --watch css/dev/style.scss:css/style.css --style compressed

exit 0
